
# Lupus Project


1\. Dataset description
=======================

fs53\_calosc
------------

Description of the MRI results for all 3 classes of patients (SLE, MS and CHECK). Also has the date of the test because some patients have two tests done (the tests were done in 2014 and 2015). If there were two tests, there is also a mri\_day\_diff which tells us the difference between the dates in days.

There are also:

*   BrainSegVolYearlyPercChange
*   BrainSegVolNotVentYearlyPercChange
*   VentYearlyPercChange

which show the change in the brain between the two MRIs.

kontrola
--------

### Arkusz1

Tests on different kinds of proteins (same tests as in the SM file).

### objętości MR

Contains the fs\_calosc but only for the CHECK group (grupa kontrolna).

MR\_objetosci\_slems\_fs53
--------------------------

### Arkusz1

Contains the fs\_calosc but without the CHECK group (grupa kontrolna) (actually almost because there is one person left with the number slems906).

### Sheet1

Consists of information about all kinds of patients about:

*   gender (gender)
*   if they are in SLE (SLE\_qualify)
*   if they are in MS (MS\_qualify)
*   if they are in CHECK (NE\_qualify)

SM
--

Information about the MS patients:

*   what were their treatments
*   tests on different kinds of proteins

TRU
---

### Arkusz1

no idea what it's about, no column names

### objawy i SLEDAI

“SYSTEMIC LUPUS ERYTHEMATOSUS DISEASE ACTIVITY INDEX

The SLEDAI measures disease activity within the last 10 days. A global index, it includes 24 clinical and laboratory variables that are weighted by the type of manifestation, but not by severity. Thus, vasculitis engenders far more points than thrombocytopenia, but a platelet count of 80 renders the same score as a platelet count of 5. Disease activity may in theory range from 0 to 105, but when this index is properly scored it is rare to find a patient with a score over 20. The SLEDAI includes scoring for the presence of autoantibodies (anti-dsDNA antibodies titers) and low complement, as well as for some renal and hematologic parameters. The index has been validated, and demonstrated to be reliable and sensitive to change.”

### przeciwciała

Tests on different kinds of proteins (same tests as in the SM file) but also describes the [SLICC damage index](https://www.google.com/url?q=https://qxmd.com/calculate/calculator_336/slicc-acr-damage-index&sa=D&source=editors&ust=1699020749869351&usg=AOvVaw3hH4nc2bGdsLpFpSRn6rY9) .

wiek
----

Has the age of all patients as well as mapping to old patients ID if it was changed.

wyniki\_testow\_psychologicznych
--------------------------------

### test papier ołówek

“Do najczęściej stosowanych testów należą testy typu „papier ołówek” – polegają dosłownie na udzielaniu odpowiedzi na zadanie pytania poprzez albo zakreślanie danej odpowiedzi albo jej wpisywaniem.”

Some columns have uneven types of data e.g. >16, 11-16, 16. How do we handle that?

There is column  “zmiany w MR” which is boolean.

### ANAM testy

[“](https://www.google.com/url?q=https://apps.dtic.mil/sti/pdfs/ADA549141.pdf&sa=D&source=editors&ust=1699020749870951&usg=AOvVaw0slj6maIKPjDqLb5o3PMhL)[The ANAM is a computer-based test system for assessing human performance and](https://www.google.com/url?q=https://apps.dtic.mil/sti/pdfs/ADA549141.pdf&sa=D&source=editors&ust=1699020749871200&usg=AOvVaw3ozmjY3R63RBtoMGXPjp5L)

[neuropsychological function.](https://www.google.com/url?q=https://apps.dtic.mil/sti/pdfs/ADA549141.pdf&sa=D&source=editors&ust=1699020749871536&usg=AOvVaw3ut1kEw46K5K09wkefMdKF) [“](https://www.google.com/url?q=https://apps.dtic.mil/sti/pdfs/ADA549141.pdf&sa=D&source=editors&ust=1699020749871723&usg=AOvVaw3fpf9pSqPLBUkRfUk5WHv6)

There is column  “zmiany w MR” which is boolean.

### Arkusz3

Consists of the outcomes of many tests (one column = one test).


1\. Files description
=======================

main.py
------------


app.py
------------


data_clean_up.py
------------


data_split.py
------------


id_mapping.py
------------


preprocessing.py
------------
