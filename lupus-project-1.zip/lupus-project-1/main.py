from src.lupus_project.app import app
import sys

def main(*argv):
    sys.stdout.reconfigure(encoding='utf-8')
    app(*argv)
    return 0

if __name__ == '__main__':
    main(*sys.argv)
