from os import listdir
from os.path import isfile, join

import numpy as np
import pandas as pd
from IPython.display import display
from src.lupus_project.notebook_funcs.id_mapping import *
from src.lupus_project.notebook_funcs.preprocessing import *
from src.lupus_project.notebook_funcs.data_clean_up import data_cleaunp
from src.lupus_project.notebook_funcs.data_split import group_k_fold
from src.lupus_project.notebook_funcs.correlation import decorrelate
from src.lupus_project.notebook_funcs.model import *
from sklearn.ensemble import *
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression

def app(argv):

    data_path = "./data/"
    file_names = [f for f in listdir(data_path) if isfile(join(data_path, f)) and ".csv" in f]
    files = [pd.read_csv(data_path+f,thousands=',') for f in file_names]
    file_tables = dict(zip(file_names,files))

    filtered_age, id_mapping = get_id_mapping(file_tables["wiek.csv"])

    file_tables["wiek.csv"] = filtered_age

    data_cleaunp(file_tables)

    #filled,no_fill = join_tables(file_tables,id_mapping)
    
    #display(filled)
    #filled.to_csv("SLEMS_filled.csv")

    #print(group_k_fold(filled))

    #print(data_fixup(filled,0.90)[0])

    #model(filled)
    #model_ANAM(filled)

    mri_file,anam_file,anam_file2 = "fs53_calosc.csv","wyniki_testow_psychologicznych_ANAM_testy.csv","wyniki_testow_psychologicznych_3.csv"
    non_anam_files = ['fs53_calosc.csv', 'kontrola_1.csv', 'MR_objetosci_slems_fs53.csv', 'SM.csv', 'TRU_2.csv', 'TRU_3.csv']
    non_and_anam_files = ['fs53_calosc.csv', 'kontrola_1.csv', 'MR_objetosci_slems_fs53.csv', 'SM.csv', 'TRU_2.csv', 'TRU_3.csv', "wyniki_testow_psychologicznych_3.csv"]
    # mri_anam,_ = join_tables({k: file_tables[k] for k in (mri_file,anam_file)},id_mapping)
    # mri_anam = preprocessing_pipeline(mri_anam,"Mri Anam joined")
    # display(mri_anam)
    #model_MRI_to_ANAM(mri_anam,file_tables[mri_file],file_tables[anam_file])
    mri_anam,_ = join_tables({k: file_tables[k] for k in (mri_file,anam_file2)},id_mapping)
    non_anam,_ = join_tables({k: file_tables[k] for k in non_anam_files}, id_mapping)
    all_tables,_ = join_tables({k: file_tables[k] for k in non_and_anam_files}, id_mapping)

    mri_anam = preprocessing_pipeline(mri_anam,"Mri Anam joined")

    models = GradientBoostingRegressor(), AdaBoostRegressor(n_estimators=200,learning_rate=2)
    Models_names = ["GradientBoostingRegressor",  "AdaBoostRegressor"]
    aggregation_metrics= ["mean", "std", "median"]

    working_models = []
    models_feature_importance = pd.DataFrame()
    info = pd.DataFrame()
    #_,mri_anam,_ = decorrelate(mri_anam)
    for j in range(len(aggregation_metrics)):
        for i in range(len(Models_names)):
            try:
                feature_importance, info_row = model_table_to_ANAM(file_tables,id_mapping,non_anam_files,anam_file2,model=models[i],loss=mean_absolute_error,aggregate=anam2_aggregate, aggregation_metric=aggregation_metrics[j])
                feature_importance = feature_importance.to_frame(name=f"Model {Models_names[i]} {aggregation_metrics[j]}")
                info_row_df = pd.DataFrame([info_row], index=[f"Model {Models_names[i]} {aggregation_metrics[j]}"])
                # print(list(feature_importance.columns))
                # feature_importance[f"Model {Models_names[i]} {aggregation_metrics[j]}"] = feature_importance[f"Model {Models_names[i]} {aggregation_metrics[j]}"].abs() / feature_importance[f"Model {Models_names[i]} {aggregation_metrics[j]}"].abs().sum() * 100
                info = pd.concat([info, info_row_df])
                print(info_row_df)
                if i!=0 or j!=0:
                    models_feature_importance = pd.merge(models_feature_importance, feature_importance, how='outer', left_index=True, right_index=True)
                else:
                    models_feature_importance = feature_importance.copy()
                working_models.append(models[i])
            except Exception as e:
                print(f"Model {Models_names[i]} is not working. Error: {e} ")

    mri_anam.to_csv("mri_anam.csv")

    # model_MRI_to_ANAM(mri_anam,file_tables[mri_file],file_tables[anam_file2],model=AdaBoostRegressor(n_estimators=200,learning_rate=2),loss=mean_absolute_error,aggregate=anam2_aggregate)

    print(models_feature_importance)

    models_feature_importance['feature_value'] = models_feature_importance.sum(axis=1)
    top_10_values = models_feature_importance.nlargest(10, 'feature_value').sort_values(by='feature_value').drop(columns="feature_value")

    top10_columns = list(top_10_values.columns)

    print(info.sort_values(by=list(info.columns)))

    fig = px.bar(top_10_values, x=top10_columns, y=top_10_values.index, labels={'x': 'feature name', 'y': 'feature value'}, barmode='group', title='Feature importance')
    fig.show()

    # fig = px.bar(
    #                 x=top_10_values.index, 
    #                 y=top_10_values.values,
    #                 orientation='h', 
    #                 width=750, 
    #                 height=(50*750),
    #                 text=top_10_values.round(3))
    # fig.update_layout(title_text="Feature importance", title_x=0.5) 
    # fig.update(layout_showlegend=False)
    # fig.update_yaxes(tickfont=dict(family='Courier New', 
    #                                 size=15),
    #                     title='')
    # fig.show()


    return 0
