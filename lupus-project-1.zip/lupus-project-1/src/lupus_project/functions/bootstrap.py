from src.lupus_project.notebook_funcs.data_split import *
from sklearn.utils import resample
import numpy as np
from sklearn.metrics import explained_variance_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.base import clone

def bootstrap(X,y,model,loss_func:callable,n=100):
    '''
    implements bootstrapping for any model

    n specifies the number of bootstraps
    
    returns trained model, loss function at each bootstrap
    '''

    train_idx,test_idx = next(group_k_fold(X))
    X = X.drop(columns="id")
    X_train,y_train,X_test,y_test =  X.iloc[train_idx],y[train_idx],X.iloc[test_idx],y[test_idx]

    bootstrap_metric = []

    model.fit(X_train,y_train)

    for _ in range(n):

        X_boot, y_boot = resample(X_train,y_train,replace=True,random_state=np.random.randint(1000))

        #print(X_boot,y_boot)
        #model.fit(X_boot,y_boot)

        y_pred = model.predict(X_boot)

        bootstrap_metric.append(explained_variance_score(y_boot,y_pred))

    bootstrap_metric_array = np.array(bootstrap_metric)

    # plt.hist(bootstrap_metric_array, bins='auto', density=True, alpha=0.75)

    # # sns.kdeplot(x=bootstrap_metric_array)
    # plt.title(f"Accuracy across {n} bootstrap samples")
    # plt.xlabel("Accuracy")
    # plt.show()


    return model,bootstrap_metric,X_train,X_test,y_train,y_test

def bootstrap_model(X,y,model,loss_func:callable,n=50):
    '''
    implements bootstrapping for any model

    n specifies the number of bootstraps
    
    returns trained model, loss function at each bootstrap
    '''

    train_idx,test_idx = group_split(X)
    X = X.drop(columns="id")
    X_train,y_train,X_test,y_test =  X.iloc[train_idx],y[train_idx],X.iloc[test_idx],y[test_idx]

    predicts = []
    bootstrap_metrics = []

    #model.fit(X_train,y_train)
    
    for _ in range(n):
        boot_model = clone(model)

        X_boot, y_boot = resample(X_train,y_train,n_samples=10,replace=True,random_state=np.random.randint(1000))

        #print(X_boot,y_boot)
        #model.fit(X_boot,y_boot)


        boot_model.fit(X_boot,y_boot)

        y_pred = boot_model.predict(X_test)
        predicts.append(y_pred)
        bootstrap_metrics.append(explained_variance_score(y_test,y_pred))

    # sns.kdeplot(bootstrap_metrics)
    # plt.title(f"Accuracy across {n} bootstrap samples")
    # plt.xlabel("Accuracy")
    # plt.show()

    
    predicts = np.mean(predicts,axis=0)

    return predicts,bootstrap_metrics,X_train,X_test,y_train,y_test