import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import seaborn as sns
import matplotlib.pyplot as plt


def decorrelate(original_file: pd.DataFrame, correlation_threshold: float = 1.0) -> (list,pd.DataFrame,pd.DataFrame):
    """ 
        Function that calculates correlation between all columns and returns the list of column with cor. >= trehole, changed df and original df.
    """

    correlated_columns = []
    original_file_copy = pd.DataFrame(original_file)
    categorical_columns = original_file.select_dtypes(exclude=np.number).columns

    original_file_copy[categorical_columns] = original_file_copy[categorical_columns].astype('category')
    original_file_copy[categorical_columns] = original_file_copy[categorical_columns].apply(lambda x: x.cat.codes)

    corr = original_file_copy.corr('spearman')
    #sns.heatmap(corr, cmap='viridis', cbar_kws={'label': 'correlation'})
    #plt.show()

    for i in range(len(corr.columns)):
        for j in range(i):
            cor_val = corr.iloc[i,j]
            if pd.isna(cor_val) or abs(cor_val) < correlation_threshold:
                continue
            colname = corr.columns[i]
            correlated_columns.append(colname)

    correlated_columns = np.unique(correlated_columns)



    return correlated_columns, original_file.drop(columns=correlated_columns), original_file