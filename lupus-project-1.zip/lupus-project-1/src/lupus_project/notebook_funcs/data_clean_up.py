import re
import numpy as np
import pandas as pd
from typing import Dict
from IPython.display import display

def remove_after_parenthesis(column_series):
    def remove_function(value):
        if isinstance(value, str) and '(' in value:
            return value.split('(', 1)[0].strip()
        return value
    column_series = column_series.apply(remove_function)
    return column_series

def extract_value(input_string):
    if not isinstance(input_string, (str, bytes)):
        raise TypeError("Input must be a string or bytes-like object")
    
    if '(' in input_string and ')' in input_string:
        match = re.search(r'\((.*?)\)', input_string)
        if match:
            return match.group(1)
    else:
        match = re.search(r'>\s*(\d+)', input_string)
        if match:
            return match.group(1)
    
    return input_string

def data_cleaunp(file_tables:Dict[str,pd.DataFrame]):

  """## Standarise all id's with table explanations

  ### MR_objetosci_slems_fs53

  Description:
  """

  df = file_tables["MR_objetosci_slems_fs53.csv"]
  df.rename(columns={"ID_c": "id_slems"},inplace=True)
  df.drop('Unnamed: 6', axis=1,inplace=True)
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)

  """### SM

  Description:
  """

  df = file_tables["SM.csv"]
  df.rename(columns={"Unnamed: 0": "id_slems"},inplace=True)
  df.drop('Unnamed: 11', axis=1,inplace=True)
  unique_value_counts = df.apply(lambda x: x.nunique())
  columns_to_drop = unique_value_counts[unique_value_counts == 1].index
  df.drop(columns=columns_to_drop,inplace=True)
  df.dropna(axis=1, how='all',inplace=True)
  #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  file_tables["SM.csv"] = df

  """### TRU_1

  Description: this table is useless
  """

  del file_tables["TRU_1.csv"]

#   df = file_tables["TRU_1.csv"]
#   df = df.rename(columns={"Unnamed: 0": "id_slems"})
#   df = df.drop('Unnamed: 1', axis=1)
#   unique_value_counts = df.apply(lambda x: x.nunique())
#   columns_to_drop = unique_value_counts[unique_value_counts == 1].index
#   df = df.drop(columns=columns_to_drop)
#   df = df.dropna(axis=1, how='all')
#   #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
#   df = df.drop(5)
#   df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
#   df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
#   file_tables["TRU_1.csv"] = df

  """### TRU_2

  Description:

  Note: There are sooo many Nan's in this table, look at last ~15 rows, some are entirely empty, and most have like 1 element, i dont even know what to do with it
  """

  df = file_tables["TRU_2.csv"]
  df = df.rename(columns={"Unnamed: 0": "id_slems"})
  df = df.drop(['SLE_qualify'], axis=1)
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  df = df.apply(lambda col: col.map(lambda value: 0 if isinstance(value, str) and value.endswith('/0') else value))
  df['SLEDAI po roku '] = remove_after_parenthesis(df['SLEDAI po roku '])
  df["NPSLE"].apply(lambda x: 1 if 'NPSLE' in str(x) else 0)
  df.drop('NPSLE.1',axis=1, inplace=True)
  df.drop('neurolupus',axis=1, inplace=True)
  df = df.iloc[:, : df.columns.get_loc('Headache')]
  df['SLICC po roku'] = df['SLICC po roku'].astype(str).str.extract(r'(\d+)').astype(float)
  df['SLICC/ACR  Damage Index '] = df['SLICC/ACR  Damage Index '].apply(lambda x: extract_value(x) if pd.notna(x) else x)
  df = df.drop(["SLE_diagno"], axis=1)
  file_tables["TRU_2.csv"] = df

  """### TRU_3

  Description:
  """

  df = file_tables["TRU_3.csv"]
  df = df.rename(columns={"Unnamed: 0": "id_slems"})
  unique_value_counts = df.apply(lambda x: x.nunique())
  columns_to_drop = unique_value_counts[unique_value_counts == 1].index
  df = df.drop(columns=columns_to_drop)
  df = df.dropna(axis=1, how='all')
  #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  df['SLICC/ACR  Damage Index '] = df['SLICC/ACR  Damage Index '].apply(lambda x: extract_value(x) if pd.notna(x) else x)
  df.replace('uj.', 0, inplace=True)
  df.replace('dod.(+)', 1, inplace=True)
  df.replace('dod.(++)', 2, inplace=True)
  df.replace('dod.(+++)', 3, inplace=True)
  df.replace('BRAK PRoBKI', np.nan, inplace=True)
  file_tables["TRU_3.csv"] = df

  """### fs53_calosc

  Description:

  Note: dormi and date_mri potentially to be removed
  """

  df = file_tables["fs53_calosc.csv"]
  df = df.rename(columns={"ID_raw": "id_slems"})
  df = df.drop(['Measure:volume', 'ID_orig'], axis=1)
  unique_value_counts = df.apply(lambda x: x.nunique())
  columns_to_drop = unique_value_counts[unique_value_counts == 1].index
  df = df.drop(columns=columns_to_drop)
  df = df.dropna(axis=1, how='all')
  #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  df = df.drop(['date_mri',"domri"], axis=1)
  file_tables["fs53_calosc.csv"] = df

  """### kontrola_1

  Description:

  Note: 31 columns have ONLY Nan's in this table
  """

  df = file_tables["kontrola_1.csv"]
  df = df.rename(columns={"Unnamed: 0": "id_slems"})
  df = df.drop(columns='Unnamed: 8')
  unique_value_counts = df.apply(lambda x: x.nunique())
  columns_to_drop = unique_value_counts[unique_value_counts == 1].index
  df = df.drop(columns=columns_to_drop)
  df = df.dropna(axis=1, how='all')
 #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  file_tables["kontrola_1.csv"] = df


  # """### wiek

  # Description:
  # """

  # df = file_tables["wiek.csv"]
  # df = df.rename(columns={"Unnamed: 0": "id_slems", "Unnamed: 2": "age"})
  # df = df.dropna(axis=1, how='all')
  # df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  # df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  # file_tables["wiek.csv"] = df

  """### wyniki_testow_psychologicznych_3

  Description:
  """

  df = file_tables["wyniki_testow_psychologicznych_3.csv"]
  df = df.rename(columns={"SLEMS ID": "id_slems"})
  df = df.drop(columns=['Uwagi',"Order"])
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  file_tables["wyniki_testow_psychologicznych_3.csv"] = df

  """### wyniki_testow_psychologicznych_ANAM_testy

  Description:

  Note: This table initially had wrong header, be carefull
  """

  df = file_tables["wyniki_testow_psychologicznych_ANAM_testy.csv"]
  df.columns = df.iloc[1]
  df = df.drop([0,1])
  df = df.rename(columns={"ID": "id_slems"})
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  df = df.apply(lambda val: pd.to_numeric(val,errors="ignore"))
  file_tables["wyniki_testow_psychologicznych_ANAM_testy.csv"] = df

  """### wyniki_testow_psychologicznych_test_papier_olowek

  Description:
  """

  df = file_tables["wyniki_testow_psychologicznych_test_papier_olowek.csv"]
  df = df.rename(columns={df.columns[0]: "id_slems"})
  unique_value_counts = df.apply(lambda x: x.nunique())
  columns_to_drop = unique_value_counts[unique_value_counts == 1].index
  df = df.drop(columns=columns_to_drop)
  df = df.dropna(axis=1, how='all')
  #print(f"Number of columns dropped with no unique value: {len(columns_to_drop)}")
  df['id_slems'] = df['id_slems'].str.replace(r'slems0*(\d+)', r'slems\1', regex=True)
  df['id_slems'] = df['id_slems'].apply(lambda x: x.replace("*", ""))
  df = df.drop(['CTT-1_cent', 'CTT-2_cent', 'CTT_BKC1_cent', 'CTT_PB1_cent', 'CTT_BKK2_cent', 'CTT_PB2_cent', 'CTT_P2_cent', 'CTT_WZ_cent'], axis=1)
  file_tables["wyniki_testow_psychologicznych_test_papier_olowek.csv"] = df

  # """## Map all id's to new ones"""

  # mapping = pd.DataFrame()
  # mapping['original_id'] = wiek['id_slems'].apply(lambda x: x.replace("*", ""))
  # mapping['new_id'] = wiek['age']
  # mapping = mapping[mapping['new_id'].str.contains('slems')]
  # new_rows = pd.DataFrame([{'original_id': 'slems905', 'new_id': 'slems139'},
  #             {'original_id': 'slems908', 'new_id': 'slems142'}])
  # mapping = pd.concat([mapping, new_rows], ignore_index=True)

  # def update_id(data, mapping):
  #   data.loc[data['id_slems'].isin(mapping['original_id']), 'id_slems'] = data['id_slems'].map(mapping.set_index('original_id')['new_id'])


  # for name,df in file_tables.item:
  #     update_id(df, mapping)
