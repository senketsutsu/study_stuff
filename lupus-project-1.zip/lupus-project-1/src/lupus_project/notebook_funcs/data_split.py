import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold,GroupShuffleSplit,StratifiedGroupKFold

def group_k_fold(df,group="id"):

    gkf = GroupKFold(n_splits=3)

    return gkf.split(df,groups=df[group])

def group_split(df,group="id"):
    splitter = GroupShuffleSplit(test_size=0.2, n_splits=2, random_state = np.random.randint(1000))
    return next(splitter.split(df, groups=df[group]))

def stratified_group_k_fold(X,y,group="id"):
    splitter = StratifiedGroupKFold(2,True,random_state = np.random.randint(1000))
    return next(splitter.split(X,y,groups=X[group]))