import numpy as np
import pandas as pd


def get_id_mapping(age_file: pd.DataFrame) -> (pd.DataFrame,pd.DataFrame):
    """ Function that retrieves the id mappings from the 'wiek.csv' file. 
        
        Returns the filtered "wiek.csv" file and the id mapping
    """
    age_file.columns = ("id",None,"age")
    age_file = age_file[["id","age"]].drop(0)
    #change slem01 to slem1
    age_file['id'] = age_file['id'].str.replace(r'slems0+(\d+)', r'slems\1', regex=True)
    age_file['age'] = age_file['age'].str.replace(r'slems0+(\d+)', r'slems\1', regex=True)

    #create table with all_id
    all_id = pd.DataFrame()
    all_id['id'] = age_file['id'].apply(lambda x: x.replace("*", ""))

    #create table with mapping
    mapping = pd.DataFrame()
    mapping['original_id'] = age_file['id'].apply(lambda x: x.replace("*", ""))
    mapping['new_id'] = age_file['age']
    mapping = mapping[mapping['new_id'].str.contains('slems')]
    new_rows = pd.DataFrame([{'original_id': 'slems905', 'new_id': 'slems139'},
                {'original_id': 'slems908', 'new_id': 'slems142'}])
    mapping = pd.concat([mapping, new_rows], ignore_index=True)

    

    age_file = age_file[age_file.age.str.isnumeric()]
    age_file ["age"] = age_file["age"].astype(int)


    #map old id's to new ones
    mapped_id = all_id[~all_id['id'].isin(mapping['original_id'])]

    #all id's
    #display(all_id)
    #mappings of all id's
    #only id's that are not repeated
    #display(mapped_id)

    return age_file,mapped_id