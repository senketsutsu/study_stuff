import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler,MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import export_text
from sklearn.experimental import enable_hist_gradient_boosting
from sklearn.metrics import mean_absolute_error, median_absolute_error, mean_squared_error, explained_variance_score
from sklearn.model_selection import train_test_split
from src.lupus_project.notebook_funcs.data_split import group_k_fold
import plotly.graph_objects as go
from src.lupus_project.functions.bootstrap import bootstrap_model,bootstrap
from src.lupus_project.functions.feature_importance import FeatureImportance
from typing import List
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
import plotly.express as px
from src.lupus_project.notebook_funcs.preprocessing import *
import shap


def plot_both(train_true, train_predicted, test_true, test_predicted, range = None):
    
    train_true = pd.Series(train_true).reset_index(drop=True)
    train_predicted = pd.Series(train_predicted).reset_index(drop=True)
    test_true = pd.Series(test_true).reset_index(drop=True)
    test_predicted = pd.Series(test_predicted).reset_index(drop=True)

    add_dist = 0.01

    if range is None:
        _max = max(max(max(max(train_predicted), max(train_true) ), max(test_predicted)), max(test_true)) + add_dist
    else:
        _max = range

    fig = go.Figure(data = go.Scatter(
            x = [-add_dist, _max],
            y = [-add_dist, _max],
            mode = 'lines',
            showlegend = False,
            hoverinfo = 'none',
            line_color = '#9a9a9a',
            line_dash = 'dash'
        ), layout = go.Layout(
                title = go.layout.Title(
                    text = "Train and test set comparison",
                    font_size = 30
                    ),
                title_x = 0.5,
                xaxis_range = [-add_dist, _max],
                yaxis_range = [-add_dist, _max]
            ))

    fig.add_traces(go.Scatter(name = "train",
                     x = train_true,
                     y = train_predicted,
                     mode ='markers',
                     marker_color = "#9a9a9a",
                     marker_size = 10,
                     hoverinfo = 'text', 
                     text = [f'True = {x}<br>Predicted = {y}' for x, y in zip(train_true, train_predicted)],  
                     ))
    
    fig.add_traces(go.Scatter(name = "test",
                     x = test_true,
                     y = test_predicted,
                     mode = 'markers',
                     marker_color = "#636efa",
                     marker_size = 10,
                     hoverinfo = 'text', 
                     text = [f'True = {x}<br>Predicted = {y}' for x, y in zip(test_true, test_predicted)],  
                     ))
    
    fig.update_xaxes(
                    title_text = "True value",
                    title_font_size = 22,
                    tickfont_size = 15,
                    tickmode = 'auto',
                    showline = True, 
                    linewidth = 1.25, 
                    linecolor = 'black',
                    minor = dict(
                        ticklen = 6,
                        ticks = "inside", 
                        tickcolor = "black", 
                        showgrid = True
                        )
                    )
    fig.update_yaxes(
                    title_text = "Predicted value",
                    title_font_size = 22,
                    tickfont_size = 15,
                    showline = True, 
                    linewidth = 1.25, 
                    linecolor = 'black',
                    minor = dict(
                        ticklen = 6,
                        ticks = "inside",
                        tickcolor = "black", 
                        showgrid = True
                        )
                    )
    
    
    fig.show()


def plot(true, predicted,title):

    true = pd.Series(true).reset_index(drop=True)
    predicted = pd.Series(predicted).reset_index(drop=True)

    color = [ (true[i] - predicted[i]) for i in range(len(true))]

    add_dist = 0.01

    y_max = max(predicted) + add_dist
    x_max = max(true) + add_dist

    _max = max(y_max,x_max)

    fig = go.Figure(data=go.Scatter(
            x=[-add_dist, _max],
            y=[-add_dist, _max],
            mode='lines',
            showlegend = False,
            hoverinfo='none',
            line_color='#9a9a9a',
            line_dash = 'dash'
        ), layout=go.Layout(
                title=go.layout.Title(
                    text=f"Overestimation and underestimation\n{title}",
                    font_size=30
                    ),
                title_x = 0.5,
                xaxis_range = [-add_dist, _max],
                yaxis_range = [-add_dist, _max]
            ))

    fig.add_traces(go.Scatter(x=true,
                     y=predicted,
                     mode='markers',
                     marker_color=color,
                     showlegend = False,
                     marker_colorscale = 'Turbo',
                     marker_size = 10,
                     hoverinfo='text', 
                     text=[f'True = {x}<br>Predicted = {y}' for x, y in zip(true, predicted)],  
                     marker_colorbar = dict(
                        title='Distance from true value',
                        titleside='right',
                        outlinewidth=1,
                        title_font_size=22,
                        tickfont_size=15

                        
                    )
                     ))
    
    fig.update_xaxes(
                    title_text="True value",
                    title_font_size=22,
                    tickfont_size=15,
                    tickmode='auto',
                    showline=True, 
                    linewidth=1.25, 
                    linecolor='black',
                    minor=dict(
                        ticklen=6,
                        ticks="inside", 
                        tickcolor="black", 
                        showgrid=True
                        )
                    )
    fig.update_yaxes(
                    title_text="Predicted value",
                    title_font_size=22,
                    tickfont_size=15,
                    showline=True, 
                    linewidth=1.25, 
                    linecolor='black',
                    minor=dict(
                        ticklen=6,
                        ticks="inside",
                        tickcolor="black", 
                        showgrid=True
                        )
                    )
    
    
    fig.show()

def model(processed_data: pd.DataFrame,target_columns: List[str]):
    df = processed_data
    df = df.fillna(0)


    numeric_columns = df.drop(columns=target_columns+["id"]).select_dtypes(include=[np.number]).columns.tolist()

    #remaining_columns = [col for col in df.columns if col not in (numeric_columns + [target_column])]

    categorical_columns = df.drop(columns=target_columns+["id"]).select_dtypes(exclude=[np.number]).columns.tolist()

    df[categorical_columns] = df[categorical_columns].astype(str)

    preprocessor = ColumnTransformer(
        transformers=[
            ('numeric', StandardScaler(), numeric_columns),
            ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
            #('remaining', SimpleImputer(strategy='mean'), remaining_columns)
        ])

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', RandomForestRegressor())
    ])
    
    X = df.drop(columns=target_columns+["id"])
    y = df[target_columns]

    train_idx,test_idx = tuple(group_k_fold(df))[0]

    X_train, X_test, y_train, y_test = X.iloc[train_idx],X.iloc[test_idx],y[train_idx],y[test_idx]

    pipeline.fit(X_train, y_train)


    train_predictions = pipeline.predict(X_train)


    test_predictions = pipeline.predict(X_test)


    train_mean_absolute_error = mean_absolute_error(y_train, train_predictions)
    test_mean_absolute_error = mean_absolute_error(y_test, test_predictions)

    train_median_absolute_error = median_absolute_error(y_train, train_predictions)
    test_median_absolute_error = median_absolute_error(y_test, test_predictions)

    print(y_test,test_predictions)
    plot(y_test, train_predictions)

    print(f"Training Mean Absolute Error: {train_mean_absolute_error}")
    print(f"Test Mean Absolute Error: {test_mean_absolute_error}")
    print(f"Training Median Absolute Error: {train_median_absolute_error}")
    print(f"Test Median Absolute Error: {test_median_absolute_error}")

    return 0

def train_and_test_model(X,y,loss,model):


    numeric_columns = X.drop(columns="id").select_dtypes(include=[np.number]).columns.tolist()

    #remaining_columns = [col for col in df.columns if col not in (numeric_columns + [target_column])]

    categorical_columns = X.drop(columns="id").select_dtypes(exclude=[np.number]).columns.tolist()

    X[categorical_columns] = X[categorical_columns].astype(str)

    preprocessor = ColumnTransformer(
        transformers=[
            ('numeric', MinMaxScaler(), numeric_columns),
            ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
            #('remaining', SimpleImputer(strategy='mean'), remaining_columns)
        ])

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', model)
    ])


    pipeline, bootstrap_metrics, X_train, X_test, y_train, y_test = bootstrap(X,y,pipeline,loss)
    #test_predictions,bootstrap_metrics,X_train,X_test,y_train,y_test = bootstrap_model(X,y,pipeline,loss)

    #pipeline.fit(X_train, y_train)


    train_predictions = pipeline.predict(X_train)


    test_predictions = pipeline.predict(X_test)


    train_mean_absolute_error = loss(y_train, train_predictions)
    test_mean_absolute_error = loss(y_test, test_predictions)
    train_mean_squared_error = mean_squared_error(y_train, train_predictions)
    test_mean_squared_error = mean_squared_error(y_test, test_predictions)


    print(y_test,test_predictions)

    print(f"Loss on training: {train_mean_absolute_error}")
    print(f"Loss on test: {test_mean_absolute_error}")
    print(f"Training Mean Squared Error: {train_mean_squared_error}")
    print(f"Test Mean Squared Error: {test_mean_squared_error}")
    print(f"Accuracy on training: {explained_variance_score(y_train,train_predictions)}")
    print(f"Accuracy on test: {explained_variance_score(y_test,test_predictions)}")



    # FEATURE IMPORTANCE

    
    feature_importance = FeatureImportance(pipeline)
    feature_importance.plot(top_n_features=10, height_per_feature=50)

    feature_importance_df = feature_importance.feature_importance
    print(feature_importance_df)

    # X_transformed = preprocessor.transform(X_train) 
    # explainer = shap.Explainer(pipeline[-1])
    # shap_values = explainer(X_train)
    # shap.summary_plot(shap_values, X_train)

    # conf_matrix = confusion_matrix(y_test, np.round(test_predictions).astype(int))

    # sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', linewidths=.5, annot_kws={"size": 16})

    # plt.xlabel('Predicted Class')
    # plt.ylabel('True Class')
    # plt.title('Confusion Matrix')

    # plt.show()



    # feature_importance_calculator = FeatureImportance(pipeline, verbose=True)
    # feature_importance_calculator.get_feature_names()
    # feature_importance_calculator.get_selected_features()
    # feature_importance_calculator.get_feature_importance()
    # feature_importance_calculator.plot(top_n_features=10, height_per_feature=50)

    # PLOT

    plot_both(y_train, train_predictions, y_test, test_predictions, range = None)
  
    return pipeline, feature_importance_df, [train_mean_absolute_error, test_mean_absolute_error, train_mean_squared_error, test_mean_squared_error]

def model_ANAM(processed_data: pd.DataFrame):
    df = processed_data
    df = df.fillna(0)

    target_column = 'Aggregated_ANAM'

    selected_columns = df.filter(regex='(?=.*Mean)(?=.*%)')
    selected_columns['id'] = df['id']
    selected_columns = selected_columns.drop_duplicates(subset='id')
    selected_columns = selected_columns.dropna()
    sum_column = selected_columns.drop('id', axis=1).sum(axis=1)

    df[target_column] = sum_column/len(selected_columns.columns)
    
    X = df.drop(columns=[target_column]+list(selected_columns.drop(columns="id").columns))
    
    y = df[target_column]
    y = y.fillna(0)

    train_and_test_model(X,y,mean_squared_error,RandomForestRegressor())

    return 0

def anam_aggregate(anam_df,classes):
    selected = anam_df.filter(regex='(?=.*Correct)')
    average = selected.mean(axis=1)
    average[classes=="CHECK"] = 100
    return average

def anam2_aggregate(anam_df, classes, aggregation_metric="std"):
    anam_df['Sum_All_Rows'] = anam_df.sum(axis=1)
    if aggregation_metric == "std":
        aggregate_result = anam_df.std(axis=1)
    elif aggregation_metric == "range":
        aggregate_result = anam_df.max(axis=1) - anam_df.min(axis=1)
    elif aggregation_metric == "average":
        aggregate_result = anam_df.sum(axis=1)
    elif aggregation_metric == "mean":
        aggregate_result = anam_df.mean(axis=1)
    elif aggregation_metric == "median":
        aggregate_result = anam_df.median(axis=1)
    else:
        raise ValueError("Invalid aggregation_metric.")
    
    aggregate_result[classes == "CHECK"] = 0
    
    return aggregate_result


def model_MRI_to_ANAM(processed_data: pd.DataFrame,MRI_table: pd.DataFrame,ANAM_table:pd.DataFrame,model=None,loss=mean_squared_error,aggregate=anam_aggregate):
    new_target = 'Aggregated_ANAM'
    df = processed_data
    # selected_columns = df[ANAM_table.columns]
    # sum_column = selected_columns.drop('id', axis=1).sum(axis=1)
    # df[new_target] = sum_column/len(selected_columns.columns)
    # selected_columns = df[ANAM_table.columns].filter(regex='(?=.*Mean)(?=.*%)')
    # selected_columns['id'] = df['id']
    # selected_columns = selected_columns.drop_duplicates(subset='id')
    # selected_columns = selected_columns.dropna()
    # sum_column = selected_columns.drop('id', axis=1).sum(axis=1)
    numerical = df[ANAM_table.columns].select_dtypes(include=[np.number]).columns.tolist()
    df[numerical] = df[numerical].clip(0,2)
    df[new_target] = aggregate(df[numerical],processed_data["class"])

    df_no_check = df[processed_data["class"]!="CHECK"].copy().reset_index()
    X = df_no_check[MRI_table.columns].drop(columns="class")
    # print(X.columns)
    y = df_no_check[new_target].fillna(0)
    # y = y.fillna(0)
    # print(X.head)
    # print(y.head)
    if model is None:model = RandomForestRegressor()
    train_and_test_model(X,y,loss,model)

def model_table_to_ANAM(file_tables: pd.DataFrame,id_mapping,tables = ["fs53_calosc.csv"],ANAM_table = "wyniki_testow_psychologicznych_3.csv",model=None,loss=mean_squared_error,aggregate=anam_aggregate, aggregation_metric="mean"):
    new_target = 'Aggregated_ANAM'

    all_tables = tables[::]
    all_tables.append(ANAM_table)

    non_anam,_ = join_tables({k: file_tables[k] for k in tables}, id_mapping)
    processed_data,_ = join_tables({k: file_tables[k] for k in all_tables}, id_mapping)

    processed_data = preprocessing_pipeline(processed_data,"Table Anam joined")
    
    df = processed_data


    numerical = df[file_tables[ANAM_table].columns].select_dtypes(include=[np.number]).columns.tolist()
    df[numerical] = df[numerical].clip(0,2)
    df[new_target] = aggregate(df[numerical],processed_data["class"], aggregation_metric=aggregation_metric)

    # df["new_target2"] = np.where(processed_data['class'] == 'CHECK', 0, 1)


    # X = df[non_anam.columns].drop(columns="class")
    # print(X.columns)
    # y = df["new_target2"].fillna(0)

    df_no_check = df[processed_data["class"]!="CHECK"].copy().reset_index()
    X = df_no_check[non_anam.columns].drop(columns="class")
    print(X.columns)
    y = df_no_check[new_target].fillna(0)

    # y = y.fillna(0)
    # print(X.head)
    # print(y.head)
    if model is None:model = RandomForestRegressor()
    pipeline, feature_importance, info = train_and_test_model(X,y,loss,model)

    return feature_importance, info


def old_model_ANAM(processed_data: pd.DataFrame):
    df = processed_data
    df = df.fillna(0)

    target_column = 'Aggregated_ANAM'

    selected_columns = df.filter(regex='(?=.*Mean)(?=.*%)')
    selected_columns['id'] = df['id']
    selected_columns = selected_columns.drop_duplicates(subset='id')
    selected_columns = selected_columns.dropna()
    sum_column = selected_columns.drop('id', axis=1).sum(axis=1)

    df['Aggregated_ANAM'] = sum_column/len(selected_columns.columns)
    
    

    numeric_columns = df.drop(columns=[target_column,"id"]).select_dtypes(include=[np.number]).columns.tolist()

    #remaining_columns = [col for col in df.columns if col not in (numeric_columns + [target_column])]

    categorical_columns = df.drop(columns=[target_column,"id"]).select_dtypes(exclude=[np.number]).columns.tolist()

    df[categorical_columns] = df[categorical_columns].astype(str)

    preprocessor = ColumnTransformer(
        transformers=[
            ('numeric', StandardScaler(), numeric_columns),
            ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
            #('remaining', SimpleImputer(strategy='mean'), remaining_columns)
        ])

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', RandomForestRegressor())
    ])
    
    X = df.drop(columns=[target_column,"id"])
    y = df[target_column]
    y = y.fillna(0)

    train_idx,test_idx = tuple(group_k_fold(df))[0]

    X_train, X_test, y_train, y_test = X.iloc[train_idx],X.iloc[test_idx],y[train_idx],y[test_idx]

    pipeline.fit(X_train, y_train)


    train_predictions = pipeline.predict(X_train)


    test_predictions = pipeline.predict(X_test)


    train_mean_absolute_error = mean_squared_error(y_train, train_predictions)
    test_mean_absolute_error = mean_squared_error(y_test, test_predictions)

    # train_median_absolute_error = median_absolute_error(y_train, train_predictions)
    # test_median_absolute_error = median_absolute_error(y_test, test_predictions)

    print(y_test,test_predictions)
    plot(y_test, test_predictions,"ANAM model whole data")

    print(f"Training Mean Squared Error: {train_mean_absolute_error}")
    print(f"Test Mean Squared Error: {test_mean_absolute_error}")
    # print(f"Training Median Absolute Error: {train_median_absolute_error}")
    # print(f"Test Median Absolute Error: {test_median_absolute_error}")

    return 0