import numpy as np
import pandas as pd
import re
from typing import List
from typing import Dict
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import OrdinalEncoder


def clean_id(_id: str)->str:
  """
  Funkcja do obróbki id, która wydobywa samą liczbę z id pacjenta.

  """
  if pd.isnull(_id):
    return _id
  found_group = re.search(r'0*(\d+)', _id)
  if found_group is None: return _id
  return f"slems{found_group.group(1)}"

def preprocessing_pipeline(table:pd.DataFrame,name:str=None)->pd.DataFrame:
  """ Preprocessing pipeline that encodes the columns, fills the missing values and removes columns using variance threshold"""
  categorical_columns = table.select_dtypes(exclude=np.number).columns
  numerical_columns = table.select_dtypes(include=np.number).columns
    # column_transformer = ColumnTransformer([
    #     ('Replace NaN with No Info', SimpleImputer(strategy="most_frequent"),categorical_columns), # what to do with categorical variables?
    #     #('MICE categorical',IterativeImputer(random_state=0,initial_strategy="most_frequent"),categorical_columns),
    #     ('MICE numerical',IterativeImputer(random_state=0),numerical_columns) # use MICE to fill numerical variables
    # ])
  #table[categorical_columns] = table[categorical_columns].astype(str) # UWAGA! it is a temporary solution
  label_encoder = OrdinalEncoder(handle_unknown="use_encoded_value",unknown_value=np.nan)
  try:
    label_encoder.fit(table[list(categorical_columns)])
  except:
    table[categorical_columns] = table[categorical_columns].astype(str)
    label_encoder.fit(table[list(categorical_columns)])
  encoding = dict(zip(categorical_columns,label_encoder.categories_))
  column_encode = ColumnTransformer([
      ('Encode categorical',label_encoder,categorical_columns),
      ('Numerical passthrough', 'passthrough', numerical_columns)
  ])
  variance_thresholder = VarianceThreshold()
  
  pipeline = Pipeline([("Label Encoding",column_encode),("MICE fill",IterativeImputer(random_state=0)),("Variance threshold",variance_thresholder)])
  pipeline.fit(table)
  feature_names = pipeline.get_feature_names_out()
  feature_names = list(map(lambda s: s[s.find("__")+2:],feature_names))
  maintained_categorical = [column for column in categorical_columns if column in feature_names]
  
  transformed = pd.DataFrame(pipeline.transform(table),columns=feature_names)

  print(f"File name: {name}")
  print(f"Categorical columns: {maintained_categorical}")
  for column in maintained_categorical:
    column_encoding = encoding[column]
    print(f"Column name: {column}")
    print(f"Dtype: {table[column].dtype}")
    print(f"Values:")
    print(column_encoding)
    print("=================================")
    
    transformed[column] = transformed[column].apply(lambda i: column_encoding[min(max(0, int(i)),len(column_encoding)-1)]) # the min is a temporary solution
  
  transformed.replace('nan', np.nan, inplace=True) # UWAGA! it is a temporary solution
  return transformed

def id_fixup(table,id_mapping):
    table.rename(columns={table.columns[0]: "id"},inplace=True)
    table["id"] = table["id"].apply(clean_id)
    table["id"].apply(lambda old_id: id_mapping.get(old_id,old_id))

def drop_na(table,threshold=0.5):
  """ drop rows where all are NaN and drop columns with less than threshold% values"""
  table.dropna(how='all', inplace=True)
  table.dropna(thresh=int(len(table)*threshold),axis="columns",inplace=True)

def data_fixup(file_tables):
  """ Funkcja do fixupu danych przed uzupełnianiem
      !ZMIANY SĄ INPLACE!
  """

  """Te kolumny wydają się nie być użyteczne"""

  file_tables['fs53_calosc.csv'].drop(columns=["long","domri","ID_orig","Measure:volume"],inplace=True)

  """Obcinanie góry testów ANAM"""

  anam_df = file_tables['wyniki_testow_psychologicznych_ANAM_testy.csv']
  anam_df.columns = anam_df.iloc[1]
  anam_df.drop(index=anam_df.index[[0,1]], axis=0, inplace=True)
  #anam_df.apply(pd.to_numeric)

  """Powtórzona kolumna id"""

  file_tables['kontrola_1.csv'].drop(columns="Unnamed: 8",inplace=True)

  """To samo tutaj"""

  file_tables['SM.csv'].drop(columns="Unnamed: 11",inplace=True)



def join_tables(file_tables:Dict[str,pd.DataFrame] ,id_mapping:dict) -> (pd.DataFrame,pd.DataFrame):

  filled_join = None
  no_fill_join = None
  for file,table in file_tables.items():

    id_fixup(table,id_mapping)

    drop_na(table)
    
    if no_fill_join is None:
      no_fill_join = table.copy()
    else:
      no_fill_join = no_fill_join.merge(table,on='id',validate='m:m', how = "outer")


    processed = preprocessing_pipeline(table,file)


    if filled_join is None:
      filled_join = processed.copy()
    else:
      filled_join = filled_join.merge(processed,on='id',validate='m:m', how = "outer")

  return filled_join,no_fill_join
